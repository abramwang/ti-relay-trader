from __future__ import annotations

import json
import threading
import unittest
from decimal import Decimal
from io import BytesIO
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib import parse

from relay_sdk import (
    BatchCommandReceipt,
    CommandReceipt,
    RelayCapabilityError,
    RelayBrokerNotReadyError,
    RelayCancelRejectedError,
    RelayClient,
    RelayCommandOutcomeUnknownError,
    RelayIdempotencyError,
    RelayQueryInterruptedError,
    TRADING_SCHEMA_VERSION,
)
from relay_sdk.client import _fill_key, _order_key
from relay_sdk.errors import error_from_payload
from relay_sdk.models import Fill, Order
from relay_sdk.streaming import iter_sse_events


class RelayHandler(BaseHTTPRequestHandler):
    requests = []
    last_event_id = ""

    def do_GET(self):  # noqa: N802
        parsed = parse.urlparse(self.path)
        query = parse.parse_qs(parsed.query)
        RelayHandler.requests.append(("GET", parsed.path, query, None))
        if parsed.path == "/v1/status":
            self._json(
                {
                    "ok": True,
                    "data": {
                        "service": "relay-api",
                        "status": "ok",
                        "dependencies": {"database": {"status": "ok"}},
                    },
                }
            )
            return
        if parsed.path == "/v1/schema":
            self._json(
                {
                    "ok": True,
                    "data": {
                        "version": "relay.trading.v1alpha1",
                        "capabilities": [
                            "ledger.cursor_pagination.v1",
                            "events.cursor_resume.v1",
                            "orders.batch_child_outcomes.v1",
                            "orders.explicit_command_ids.v1",
                            "accounts.order_entry_readiness.v1",
                            "cancel_attempts.cursor_pagination.v1",
                        ],
                        "http_routes": [{"method": "GET", "path": "/v1/schema"}],
                        "redis_actions": ["order.batch.submit"],
                    },
                }
            )
            return
        if parsed.path == "/v1/accounts":
            self._json({"ok": True, "data": {"accounts": [{"account_id": "acct-1", "enabled": True}]}})
            return
        if parsed.path == "/v1/accounts/acct-1/readiness":
            ready = query.get("force", ["false"])[0] == "true"
            self._json(
                {
                    "ok": True,
                    "data": {
                        "readiness": {
                            "account_id": "acct-1",
                            "environment": "test",
                            "counter_mode": "huaxin_7x24_test",
                            "counter_session_id": "huaxin-test-session-20260915-a",
                            "order_entry_ready": ready,
                            "broker_session_state": "ready" if ready else "blocked",
                            "order_entry_block_reason": "" if ready else "OUTSIDE_TEST_COUNTER_WINDOW",
                            "observed_at": "2026-09-15T13:15:00+08:00",
                            "next_transition_at": "2026-09-15T13:25:00+08:00",
                            "order_entry_timezone": "Asia/Shanghai",
                            "order_entry_readiness_source": "oc_heartbeat+configured_test_schedule",
                            "broker_ready": True,
                            "order_snapshot_ready": True,
                            "accepting_trade_commands": True,
                        }
                    },
                }
            )
            return
        if parsed.path == "/v1/accounts/acct-1/asset":
            self._json({"ok": True, "data": {"asset": {"account_id": "acct-1", "net_asset": 123.45, "reverse_repo_receivable": 100.0}}})
            return
        if parsed.path == "/v1/accounts/acct-1/positions":
            self._json({"ok": True, "data": {"positions": [{"account_id": "acct-1", "symbol": "600000", "quantity": 100, "avg_cost": 9.54, "total_cost": 954.0, "avg_cost_source": "broker_total_position_cost", "cost_complete": True}]}})
            return
        if parsed.path == "/v1/accounts/acct-1/positions/history":
            self._json({"ok": True, "data": {"positions": [{"account_id": "acct-1", "trade_date": "2026-06-12", "snapshot_type": query.get("snapshot_type", ["close"])[0], "symbol": "600000", "quantity": 100}]}})
            return
        if parsed.path == "/v1/accounts/acct-1/performance/daily":
            self._json({"ok": True, "data": {"account_id": "acct-1", "trade_date": query.get("trade_date", [""])[0], "net_asset": 123.45}})
            return
        if parsed.path == "/v1/accounts/acct-1/performance/contributions":
            self._json(
                {
                    "ok": True,
                    "data": {
                        "contribution": {
                            "account_id": "acct-1",
                            "trade_date": query.get("trade_date", ["20260612"])[0],
                            "contributions": [
                                {
                                    "security_id": "600000.SH",
                                    "strategy_type": "stock_cross_section",
                                    "net_contribution": 100.0,
                                }
                            ],
                        }
                    },
                }
            )
            return
        if parsed.path == "/v1/accounts/acct-1/performance/trade-quality":
            self._json(
                {
                    "ok": True,
                    "data": {
                        "trade_quality": {
                            "account_id": "acct-1",
                            "date_from": query.get("date_from", query.get("trade_date", ["20260612"]))[0],
                            "date_to": query.get("date_to", query.get("trade_date", ["20260612"]))[0],
                            "summary": {
                                "orders": 10,
                                "orders_with_fills": 8,
                                "executed_order_rate": 0.8,
                            },
                            "anomalies": [],
                        }
                    },
                }
            )
            return
        if parsed.path == "/v1/accounts/acct-1/performance/series":
            self._json({"ok": True, "data": {"account_id": "acct-1", "series": [{"trade_date": "20260612", "net_asset": 123.45}]}})
            return
        if parsed.path == "/v1/accounts/acct-1/performance/economic-nav/preview":
            self._json(
                {
                    "ok": True,
                    "data": {
                        "economic_nav": {
                            "account_id": "acct-1",
                            "trade_date": query.get("trade_date", [""])[0],
                            "persisted": False,
                            "nav": {"status": query.get("status", ["provisional"])[0]},
                        }
                    },
                }
            )
            return
        if parsed.path == "/v1/accounts/acct-1/performance/cost-ledger/preview":
            self._json(
                {
                    "ok": True,
                    "data": {
                        "cost_ledger": {
                            "account_id": "acct-1",
                            "trade_date": query.get("trade_date", [""])[0],
                            "status": "calculated",
                            "persisted": False,
                            "quality_flags": [],
                        }
                    },
                }
            )
            return
        if parsed.path == "/v1/accounts/acct-1/performance/economic-nav/reconcile":
            self._json(
                {
                    "ok": True,
                    "data": {
                        "economic_nav_reconciliation": {
                            "account_id": "acct-1",
                            "trade_date": query.get("trade_date", [""])[0],
                            "observed_trade_date": query.get("observed_trade_date", [""])[0],
                            "persisted": False,
                            "status": "auto_completed",
                        }
                    },
                }
            )
            return
        if parsed.path == "/v1/accounts/acct-1/performance/economic-nav":
            self._json({"ok": True, "data": {"navs": [{"account_id": "acct-1", "trade_date": query.get("trade_date", [""])[0], "status": "provisional"}]}})
            return
        if parsed.path == "/v1/accounts/acct-1/performance/nav-reconciliations":
            self._json({"ok": True, "data": {"reconciliations": [{"account_id": "acct-1", "trade_date": query.get("trade_date", [""])[0], "status": "auto_completed"}]}})
            return
        if parsed.path == "/v1/accounts/acct-1/performance/series.csv":
            body = b"account_id,trade_date,net_asset\nacct-1,20260612,123.45\n"
            self.send_response(200)
            self.send_header("Content-Type", "text/csv")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        if parsed.path == "/v1/reconciliations/breaks":
            self._json({"ok": True, "data": {"breaks": [{"run_id": query.get("run_id", ["run-1"])[0], "status": query.get("status", ["open"])[0]}]}})
            return
        if parsed.path == "/v1/reconciliations/review-report":
            self._json({"ok": True, "data": {"trade_date": query.get("trade_date", ["20260731"])[0], "status": "passed", "accounts": []}})
            return
        if parsed.path == "/v1/jobs/runs":
            self._json({"ok": True, "data": {"runs": [{"job_name": "post_close_settlement", "target_trade_date": query.get("trade_date", [""])[0]}]}})
            return
        if parsed.path == "/v1/command-status/msg-asset-1":
            self._json(
                {
                    "ok": True,
                    "data": {
                        "origin_message_id": "msg-asset-1",
                        "account_id": "acct-1",
                        "action": "account.asset.query",
                        "expected_result_type": "asset_page",
                        "state": "completed",
                        "terminal": True,
                        "success": True,
                        "contradictory": False,
                        "reply_count": 1,
                        "terminal_count": 1,
                        "replies": [{"status": "completed", "result_type": "asset_page", "is_last": True}],
                    },
                }
            )
            return
        if parsed.path == "/v1/command-status/msg-batch-1":
            self._json(
                {
                    "ok": True,
                    "data": {
                        "origin_message_id": "msg-batch-1",
                        "account_id": "acct-1",
                        "action": "order.batch.submit",
                        "state": "pending",
                        "replies": [{"status": "partial", "is_last": False}],
                    },
                }
            )
            return
        if parsed.path == "/v1/command-status/msg-batch-unknown":
            self._json(
                {
                    "ok": True,
                    "data": {
                        "origin_message_id": "msg-batch-unknown",
                        "account_id": "acct-1",
                        "action": "order.batch.submit",
                        "state": "failed",
                        "terminal": True,
                        "replies": [
                            {
                                "status": "failed",
                                "code": "COMMAND_OUTCOME_UNKNOWN",
                                "message": "OC restarted",
                            }
                        ],
                    },
                }
            )
            return
        if parsed.path == "/v1/command-status/msg-batch-replay":
            self._json(
                {
                    "ok": True,
                    "data": {
                        "origin_message_id": "msg-batch-replay",
                        "account_id": "acct-1",
                        "action": "order.batch.submit",
                        "state": "accepted",
                        "terminal": True,
                        "success": True,
                        "replies": [{"status": "accepted", "result_type": "order_action_receipt"}],
                    },
                }
            )
            return
        if parsed.path == "/v1/meridian/market/bars":
            self._json(
                {
                    "ok": True,
                    "data": {
                        "data": [
                            {
                                "security_id": query.get("security_id", ["600000.SH"])[0],
                                "trade_date": 20260612,
                                "datetime": "2026-06-12T09:31:00+08:00",
                                "close": 9.46,
                            }
                        ],
                        "meta": {"schema_version": "market_bar.v1"},
                    },
                }
            )
            return
        if parsed.path == "/v1/meridian/metadata/instruments":
            self._json(
                {
                    "ok": True,
                    "data": {
                        "data": [
                            {
                                "security_id": "600000.SH",
                                "instrument_type": "stock",
                                "price_tick": 0.01,
                                "price_decimals": 2,
                                "price_tick_source": "rqdatac.Instrument.tick_size",
                                "price_tick_as_of_date": 20260902,
                            },
                            {
                                "security_id": "510300.SH",
                                "instrument_type": "etf",
                                "price_tick": 0.001,
                                "price_decimals": 3,
                                "price_tick_source": "rqdatac.Instrument.tick_size",
                                "price_tick_as_of_date": 20260902,
                            },
                            {
                                "security_id": "110075.SH",
                                "instrument_type": "convertible_bond",
                                "price_tick": 0.001,
                                "price_decimals": 3,
                                "price_tick_source": "rqdatac.Instrument.tick_size",
                                "price_tick_as_of_date": 20260902,
                            },
                        ],
                        "meta": {"schema_version": "metadata_instrument.v2"},
                    },
                }
            )
            return
        if parsed.path == "/v1/meridian/metadata/status":
            self._json(
                {
                    "ok": True,
                    "data": {
                        "data": {
                            "status": "ok",
                            "price_tick_quality": {
                                "status": "ready",
                                "active_total": 7187,
                                "covered_count": 7187,
                                "missing_count": 0,
                            },
                        },
                        "meta": {"schema_version": "metadata_status.v2"},
                    },
                }
            )
            return
        if parsed.path == "/v1/meridian/metadata/adjust-factors":
            self._json(
                {
                    "ok": True,
                    "data": {
                        "data": [
                            {
                                "security_id": query.get("security_id", ["600000.SH"])[0],
                                "trade_date": 20260612,
                                "adj_factor": 1.2345,
                            }
                        ],
                        "meta": {"schema_version": "metadata_adjust_factor.v1"},
                    },
                }
            )
            return
        if parsed.path == "/v1/meridian/market/etf-components":
            self._json(
                {
                    "ok": True,
                    "data": {
                        "data": [
                            {
                                "security_id": query.get("security_id", ["588200.SH"])[0],
                                "component_security_id": "688361.SH",
                                "stock_amount": "425",
                            }
                        ],
                        "meta": {"schema_version": "etf_component.v1"},
                    },
                }
            )
            return
        if parsed.path == "/v1/meridian/market/etf-cash-components":
            self._json(
                {
                    "ok": True,
                    "data": {
                        "data": [
                            {
                                "security_id": query.get("security_id", ["588200.SH"])[0],
                                "unit_subscribe_redeem": "4500000",
                            }
                        ],
                        "meta": {"schema_version": "etf_cash_component.v1"},
                    },
                }
            )
            return
        if parsed.path == "/v1/meridian/market/etf-pcf-status":
            self._json(
                {
                    "ok": True,
                    "data": {
                        "data": {"schema_version": "etf_pcf_status.v1", "state": {"status": "success"}},
                        "meta": {"schema_version": "etf_pcf_status.v1"},
                    },
                }
            )
            return
        if parsed.path == "/v1/orders":
            self._json(
                {
                    "ok": True,
                    "data": {
                        "orders": [
                            {
                                "account_id": "acct-1",
                                "gateway_order_id": query.get("gateway_order_id", ["gw-1"])[0],
                                "status": "filled",
                                "is_terminal": True,
                                "cum_filled_qty": 100,
                            }
                        ],
                        "count": 1,
                        "next_cursor": "",
                        "query": {
                            "account_id": "acct-1",
                            "gateway_order_id": query.get("gateway_order_id", [""])[0],
                            "limit": int(query.get("limit", ["100"])[0]),
                        },
                    },
                    "request_id": "req-orders-http",
                    "time": "2026-09-02T10:00:00+08:00",
                }
            )
            return
        if parsed.path == "/v1/order-cancel-attempts":
            cursor = query.get("cursor", [""])[0]
            suffix = "2" if cursor else "1"
            next_cursor = "1" if not cursor else ""
            self._json(
                {
                    "ok": True,
                    "data": {
                        "cancel_attempts": [
                            {
                                "attempt_id": f"cancel-{suffix}",
                                "account_id": "acct-1",
                                "trade_date": "2026-09-16",
                                "gateway_order_id": query.get("gateway_order_id", [f"gw-{suffix}"])[0],
                                "origin_message_id": f"msg-{suffix}",
                                "request_id": f"req-{suffix}",
                                "correlation_id": f"corr-{suffix}",
                                "status": query.get("status", ["rejected"])[0],
                                "code": "ORDER_NOT_FOUND",
                                "message": "gateway_order_id not found",
                                "retry_safe": False,
                                "order_state_changed": False,
                                "reconciliation_required": True,
                                "occurred_at": f"2026-09-16T13:1{suffix}:00+08:00",
                                "stream_key": "relay:test:v1:huaxin:00030484:reply",
                                "stream_id": f"1{suffix}-0",
                            }
                        ],
                        "count": 1,
                        "next_cursor": next_cursor,
                        "query": {
                            "account_id": "acct-1",
                            "gateway_order_id": query.get("gateway_order_id", [""])[0],
                            "status": query.get("status", [""])[0],
                            "trade_date": query.get("trade_date", [""])[0],
                            "limit": int(query.get("limit", ["100"])[0]),
                            "cursor": cursor,
                        },
                    },
                    "request_id": f"req-cancel-page-{suffix}",
                    "time": "2026-09-16T13:20:00+08:00",
                }
            )
            return
        if parsed.path == "/v1/history/orders" and query.get("origin_message_id"):
            message_id = query["origin_message_id"][0]
            if message_id == "msg-batch-unknown":
                orders = [
                    {
                        "account_id": "acct-1",
                        "gateway_order_id": "gw-unknown",
                        "client_order_id": "client-unknown",
                        "idempotency_key": "idem-unknown",
                        "origin_message_id": message_id,
                        "status": "created",
                        "adapter_context": {"batch_index": 0},
                    }
                ]
            elif message_id == "msg-batch-replay":
                orders = [
                    {
                        "account_id": "acct-1",
                        "gateway_order_id": "gw-replayed-batch",
                        "client_order_id": "client-replayed-batch",
                        "idempotency_key": "idem-replayed-batch",
                        "origin_message_id": message_id,
                        "status": "filled",
                        "is_terminal": True,
                        "adapter_context": {"batch_index": 0},
                    }
                ]
            else:
                orders = [
                    {
                        "account_id": "acct-1",
                        "gateway_order_id": "gw-batch-2",
                        "client_order_id": "client-batch-2",
                        "idempotency_key": "idem-batch-2",
                        "origin_message_id": message_id,
                        "status": "rejected",
                        "is_terminal": True,
                        "reject_code": "ORDER_SUBMIT_REJECTED",
                        "reject_message": "price rejected",
                        "adapter_context": {"batch_index": 1},
                    },
                    {
                        "account_id": "acct-1",
                        "gateway_order_id": "gw-batch-1",
                        "client_order_id": "client-batch-1",
                        "idempotency_key": "idem-batch-1",
                        "origin_message_id": message_id,
                        "status": "working",
                        "adapter_context": {"batch_index": 0},
                    },
                ]
            self._json(
                {
                    "ok": True,
                    "data": {
                        "orders": orders,
                        "count": len(orders),
                        "next_cursor": "",
                        "query": {
                            "account_id": "acct-1",
                            "origin_message_id": message_id,
                            "history": True,
                            "limit": int(query.get("limit", ["500"])[0]),
                        },
                    },
                    "request_id": "req-batch-orders",
                    "time": "2026-09-02T10:00:00+08:00",
                }
            )
            return
        if parsed.path == "/v1/fills":
            if query.get("symbol", [""])[0] == "dup-fill":
                self._json(
                    {
                        "ok": True,
                        "data": {
                            "fills": [
                                {
                                    "fill_id": "reused-fill",
                                    "account_id": "acct-1",
                                    "gateway_order_id": "gw-a",
                                    "qty": 100,
                                },
                                {
                                    "fill_id": "reused-fill",
                                    "account_id": "acct-1",
                                    "gateway_order_id": "gw-b",
                                    "qty": 200,
                                },
                            ]
                        },
                    }
                )
                return
            self._json({"ok": True, "data": {"fills": [{"fill_id": "fill-1", "account_id": "acct-1", "qty": 100}]}})
            return
        if parsed.path == "/v1/accounts/acct-1/fees":
            self._json(
                {
                    "ok": True,
                    "data": {
                        "fees": [{
                            "account_id": "acct-1",
                            "fee_record_id": "fee-1",
                            "trade_date": query.get("trade_date", [""])[0],
                            "gateway_order_id": query.get("gateway_order_id", ["gw-1"])[0],
                            "total_fee": 6.25,
                            "fee_complete": True,
                            "fee_source": "broker_order_fund_detail",
                            "association_complete": True,
                        }]
                    },
                }
            )
            return
        if parsed.path == "/v1/history/orders":
            self._json({"ok": True, "data": {"orders": [{"account_id": "acct-1", "gateway_order_id": "gw-history", "status": "filled", "is_terminal": True}]}})
            return
        if parsed.path == "/v1/history/fills":
            self._json({"ok": True, "data": {"fills": [{"fill_id": "fill-history", "account_id": "acct-1", "trade_date": query.get("trade_date", [""])[0], "qty": 100}]}})
            return
        if parsed.path in ("/v1/transfers", "/v1/history/transfers"):
            self._json(
                {
                    "ok": True,
                    "data": {
                        "transfers": [
                            {
                                "fill_id": "transfer-1",
                                "account_id": "acct-1",
                                "gateway_order_id": "gw-transfer",
                                "symbol": "300001",
                                "exchange": "SZ",
                                "qty": 300,
                                "trade_side": "R",
                                "business_type": "E",
                                "record_type": "etf_component_transfer",
                                "component_symbol": "300001",
                                "component_exchange": "SZ",
                                "component_qty": 300,
                                "component_value": None,
                            }
                        ]
                    },
                }
            )
            return
        if parsed.path == "/v1/events/stream":
            RelayHandler.last_event_id = self.headers.get("Last-Event-ID", "")
            events = [
                (
                    "order.changed",
                    {
                        "type": "order.changed",
                        "account_ids": ["acct-1"],
                        "time": "2026-06-14T00:00:00Z",
                        "data": {"orders": 1, "last_stream_id": "1-0"},
                    },
                ),
                (
                    "order.cancel.rejected",
                    {
                        "type": "order.cancel.rejected",
                        "account_ids": ["acct-1"],
                        "time": "2026-07-30T02:00:00Z",
                        "data": {
                            "cancel_failures": 1,
                            "cancel_attempt": {
                                "gateway_order_id": "gw-cancel-rejected",
                                "status": "rejected",
                                "code": "BROKER_CANCEL_REJECTED",
                            },
                        },
                    },
                ),
                (
                    "fill.changed",
                    {
                        "type": "fill.changed",
                        "account_ids": ["acct-1"],
                        "time": "2026-06-14T00:00:01Z",
                        "data": {"fills": 1, "last_stream_id": "2-0"},
                    },
                ),
                (
                    "order.changed",
                    {
                        "type": "order.changed",
                        "account_ids": ["acct-1"],
                        "time": "2026-06-14T00:00:02Z",
                        "data": {"orders": 1, "last_stream_id": "3-0"},
                    },
                ),
            ]
            body = b"".join(
                (
                    f"event: {event_name}\n"
                    f"data: {json.dumps(payload, separators=(',', ':'))}\n"
                    "\n"
                ).encode("utf-8")
                for event_name, payload in events
            )
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        self.send_error(404)

    def do_POST(self):  # noqa: N802
        parsed = parse.urlparse(self.path)
        query = parse.parse_qs(parsed.query)
        length = int(self.headers.get("Content-Length", "0"))
        body = json.loads(self.rfile.read(length).decode("utf-8") or "{}")
        RelayHandler.requests.append(("POST", parsed.path, query, body))
        if parsed.path == "/v1/orders":
            if body.get("gateway_order_id") == "gw-replay":
                self._json(
                    {
                        "ok": True,
                        "data": {
                            "account_id": body["account_id"],
                            "action": "order.submit",
                            "order": {
                                "account_id": body["account_id"],
                                "gateway_order_id": "gw-replay",
                                "client_order_id": body["client_order_id"],
                                "status": "cancelled",
                                "is_terminal": True,
                            },
                            "idempotency_key": body["idempotency_key"],
                            "message_id": "msg-replay-1",
                            "stream_key": "relay:test:v1:huaxin:gw-1:cmd.trade",
                            "stream_id": "1-0",
                            "request_id": "req-replay-1",
                            "replayed": True,
                        },
                    }
                )
                return
            order = {
                "account_id": body["account_id"],
                "gateway_order_id": body["gateway_order_id"],
                "client_order_id": body["client_order_id"],
                "idempotency_key": body["idempotency_key"],
                "status": "created",
            }
            self._json(
                {
                    "ok": True,
                    "data": {
                        "account_id": body["account_id"],
                        "action": "" if body.get("idempotency_key") == "missing-action" else (
                            "order.cancel" if body.get("idempotency_key") == "wrong-action" else "order.submit"
                        ),
                        "order": order,
                        "stream_id": "1-0",
                        "message_id": "msg-1",
                        "request_id": "req-order-1",
                        "idempotency_key": body["idempotency_key"],
                        "published": {"stream_id": "1-0"},
                    },
                },
                status=202,
            )
            return
        if parsed.path == "/v1/orders/gw-1/cancel":
            self._json(
                {
                    "ok": True,
                    "data": {
                        "account_id": body["account_id"],
                        "action": "order.cancel",
                        "order": {"account_id": body["account_id"], "gateway_order_id": "gw-1", "status": "working"},
                        "cancel_id": body["cancel_id"],
                        "idempotency_key": body["idempotency_key"],
                    },
                },
                status=202,
            )
            return
        if parsed.path == "/v1/accounts/acct-1/orders/refresh":
            self._json({"ok": True, "data": {"account_id": "acct-1", "action": "order.list.query", "stream_id": "2-0"}}, status=202)
            return
        if parsed.path == "/v1/accounts/acct-1/fills/refresh":
            self._json({"ok": True, "data": {"account_id": "acct-1", "action": "fill.list.query", "stream_id": "3-0"}}, status=202)
            return
        if parsed.path == "/v1/accounts/acct-1/fees/refresh":
            self._json({"ok": True, "data": {"account_id": "acct-1", "action": "fee.list.query", "stream_id": "6-0"}}, status=202)
            return
        if parsed.path == "/v1/accounts/acct-1/asset/refresh" or parsed.path == "/v1/accounts/acct-1/positions/refresh":
            self._json({"ok": True, "data": {"account_id": "acct-1", "action": "query", "stream_id": "4-0"}}, status=202)
            return
        if parsed.path == "/v1/orders/batch":
            orders = []
            for index, item in enumerate(body["orders"]):
                order = dict(item)
                order["status"] = "filled" if body.get("idempotency_key") == "batch-replay" else "created"
                order["is_terminal"] = body.get("idempotency_key") == "batch-replay"
                order["adapter_context"] = {"batch_index": index}
                orders.append(order)
            self._json(
                {
                    "ok": True,
                    "data": {
                        "account_id": body["account_id"],
                        "action": "order.batch.submit",
                        "orders": orders,
                        "stream_id": "5-0",
                        "message_id": "msg-batch-replay" if body.get("idempotency_key") == "batch-replay" else "msg-batch-1",
                        "request_id": "req-batch-1",
                        "idempotency_key": body["idempotency_key"],
                        "replayed": body.get("idempotency_key") == "batch-replay",
                        "published": {"stream_id": "5-0"},
                    },
                },
                status=200 if body.get("idempotency_key") == "batch-replay" else 202,
            )
            return
        if parsed.path == "/v1/jobs/runs":
            self._json({"ok": True, "data": {"run": {"run_id": "job-1", "job_name": body.get("job_name") or body.get("report", {}).get("job")}}}, status=202)
            return
        if parsed.path == "/v1/settlements/snapshots":
            self._json(
                {
                    "ok": True,
                    "data": {
                        "run_id": body.get("run_id"),
                        "trade_date": body.get("trade_date"),
                        "status": "completed",
                        "asset_snapshots": 1,
                        "position_snapshots": 1,
                    },
                },
                status=202,
            )
            return
        if parsed.path == "/v1/accounts/acct-1/performance/economic-nav/rebuild":
            self._json(
                {
                    "ok": True,
                    "data": {
                        "economic_nav": {
                            "account_id": "acct-1",
                            "trade_date": body.get("trade_date"),
                            "persisted": True,
                            "nav": {"status": body.get("status")},
                        }
                    },
                }
            )
            return
        if parsed.path == "/v1/accounts/acct-1/performance/cost-ledger/rebuild":
            self._json(
                {
                    "ok": True,
                    "data": {
                        "cost_ledger": {
                            "account_id": "acct-1",
                            "trade_date": query.get("trade_date", [""])[0],
                            "status": "calculated",
                            "persisted": True,
                            "quality_flags": [],
                        }
                    },
                }
            )
            return
        if parsed.path == "/v1/accounts/acct-1/performance/economic-nav/reconcile":
            self._json(
                {
                    "ok": True,
                    "data": {
                        "economic_nav_reconciliation": {
                            "account_id": "acct-1",
                            "trade_date": body.get("trade_date"),
                            "observed_trade_date": body.get("observed_trade_date"),
                            "persisted": True,
                            "status": "review_required",
                        }
                    },
                }
            )
            return
        if parsed.path == "/v1/accounts/acct-1/performance/nav-reconciliations/confirm":
            self._json(
                {
                    "ok": True,
                    "data": {
                        "nav_reconciliation_review": {
                            "account_id": "acct-1",
                            "trade_date": body.get("trade_date"),
                            "action": "confirm",
                            "status": "confirmed",
                            "persisted": True,
                        }
                    },
                }
            )
            return
        if parsed.path == "/v1/accounts/acct-1/performance/nav-reconciliations/block":
            self._json(
                {
                    "ok": True,
                    "data": {
                        "nav_reconciliation_review": {
                            "account_id": "acct-1",
                            "trade_date": body.get("trade_date"),
                            "action": "block",
                            "status": "blocked",
                            "persisted": True,
                        }
                    },
                }
            )
            return
        if parsed.path == "/v1/error":
            self._json({"ok": False, "error": {"code": "IDEMPOTENCY_CONFLICT", "message": "duplicate"}}, status=409)
            return
        if parsed.path == "/v1/broker-not-ready":
            self._json(
                {"ok": False, "error": {"code": "BROKER_NOT_READY", "message": "broker counter is reconnecting"}},
                status=503,
            )
            return
        self.send_error(404)

    def log_message(self, *_args):
        return

    def _json(self, payload, status=200):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


class RelayClientTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        RelayHandler.requests = []
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), RelayHandler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base_url = f"http://127.0.0.1:{cls.server.server_address[1]}"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.thread.join(timeout=2)

    def setUp(self):
        RelayHandler.requests = []
        RelayHandler.last_event_id = ""
        self.client = RelayClient(self.base_url, account_id="acct-1")

    def test_queries_return_models(self):
        self.assertEqual(self.client.status()["status"], "ok")
        self.assertEqual(self.client.list_accounts()[0].account_id, "acct-1")
        asset = self.client.get_asset()
        self.assertEqual(asset.net_asset, 123.45)
        self.assertEqual(asset.reverse_repo_receivable, 100.0)
        position = self.client.get_positions()[0]
        self.assertEqual(position.symbol, "600000")
        self.assertEqual(position.total_cost, 954.0)
        self.assertEqual(position.avg_cost_source, "broker_total_position_cost")
        self.assertTrue(position.cost_complete)

    def test_schema_capability_discovery(self):
        catalog = self.client.require_capabilities(
            "ledger.cursor_pagination.v1",
            "events.cursor_resume.v1",
            "orders.batch_child_outcomes.v1",
        )
        self.assertEqual(catalog.version, TRADING_SCHEMA_VERSION)
        self.assertTrue(catalog.supports("orders.explicit_command_ids.v1"))
        self.assertTrue(catalog.supports("accounts.order_entry_readiness.v1"))
        self.assertTrue(catalog.supports("cancel_attempts.cursor_pagination.v1"))
        with self.assertRaises(RelayCapabilityError) as raised:
            self.client.require_capabilities("future.capability.v9")
        self.assertEqual(raised.exception.code, "CAPABILITY_MISSING")
        self.assertEqual(self.client.list_orders(gateway_order_id="gw-1")[0].status, "filled")
        self.assertEqual(self.client.list_fills()[0].fill_id, "fill-1")
        self.assertEqual(self.client.list_transfers()[0].component_qty, 300)

    def test_account_readiness_and_fail_closed_verification(self):
        readiness = self.client.get_account_readiness(force=False)
        self.assertFalse(readiness.order_entry_ready)
        self.assertEqual(readiness.order_entry_block_reason, "OUTSIDE_TEST_COUNTER_WINDOW")
        self.assertEqual(readiness.counter_mode, "huaxin_7x24_test")
        self.assertEqual(readiness.counter_session_id, "huaxin-test-session-20260915-a")

        with self.assertRaises(RelayBrokerNotReadyError) as raised:
            self.client.verify_ready(force=False)
        self.assertEqual(raised.exception.code, "OUTSIDE_TEST_COUNTER_WINDOW")

        verified = self.client.verify_ready(force=True)
        self.assertTrue(verified.order_entry_ready)
        self.assertEqual(verified.broker_session_state, "ready")

    def test_order_page_preserves_real_http_envelope(self):
        page = self.client.list_orders_page(gateway_order_id="gw-1", limit=1)
        self.assertEqual(page.count, 1)
        self.assertEqual(page.items[0].gateway_order_id, "gw-1")
        self.assertTrue(page.is_complete)
        self.assertEqual(page.request_id, "req-orders-http")
        self.assertEqual(page.time, "2026-09-02T10:00:00+08:00")
        self.assertEqual(page.query["limit"], 1)

    def test_cancel_attempt_pages_preserve_rejection_evidence(self):
        page = self.client.list_cancel_attempts_page(
            gateway_order_id="gw-cross-day",
            status="rejected",
            trade_date="20260916",
            limit=1,
        )
        self.assertEqual(page.count, 1)
        self.assertEqual(page.next_cursor, "1")
        self.assertEqual(page.items[0].code, "ORDER_NOT_FOUND")
        self.assertFalse(page.items[0].retry_safe)
        self.assertFalse(page.items[0].order_state_changed)
        self.assertTrue(page.items[0].reconciliation_required)
        self.assertEqual(page.request_id, "req-cancel-page-1")
        _, path, query, _ = RelayHandler.requests[-1]
        self.assertEqual(path, "/v1/order-cancel-attempts")
        self.assertEqual(query["account_id"], ["acct-1"])
        self.assertEqual(query["trade_date"], ["20260916"])

    def test_cancel_attempt_iterators_cover_all_pages(self):
        attempts = list(
            self.client.iter_cancel_attempts(
                status="rejected",
                trade_date="20260916",
                page_size=1,
            )
        )
        self.assertEqual([item.attempt_id for item in attempts], ["cancel-1", "cancel-2"])
        pages = list(
            self.client.iter_cancel_attempt_pages(
                status="rejected",
                trade_date="20260916",
                page_size=1,
            )
        )
        self.assertEqual([page.request_id for page in pages], ["req-cancel-page-1", "req-cancel-page-2"])

    def test_raw_asset_and_position_queries_disable_enrichment(self):
        self.client.get_asset_raw()
        self.assertEqual(RelayHandler.requests[-1][2]["enrich"], ["false"])
        self.client.get_positions_raw()
        self.assertEqual(RelayHandler.requests[-1][2]["enrich"], ["false"])

    def test_command_status_returns_terminal_model(self):
        status = self.client.get_command_status("msg-asset-1")
        self.assertEqual(status.state, "completed")
        self.assertTrue(status.success)
        self.assertEqual(status.expected_result_type, "asset_page")
        self.assertEqual(status.replies[0].result_type, "asset_page")

    def test_history_queries_use_history_endpoints(self):
        open_position = self.client.get_positions(history=True, trade_date="20260612", snapshot_type="open")[0]
        self.assertEqual(open_position.trade_date, "2026-06-12")
        self.assertEqual(open_position.snapshot_type, "open")
        self.assertEqual(self.client.list_orders(history=True, date_from="20260612")[0].gateway_order_id, "gw-history")
        self.assertEqual(self.client.list_fills(history=True, trade_date="20260612")[0].fill_id, "fill-history")
        self.assertEqual(self.client.list_transfers(history=True, trade_date="20260612")[0].fill_id, "transfer-1")
        self.assertEqual(RelayHandler.requests[-4][1], "/v1/accounts/acct-1/positions/history")
        self.assertEqual(RelayHandler.requests[-4][2]["snapshot_type"], ["open"])
        self.assertEqual(RelayHandler.requests[-3][1], "/v1/history/orders")
        self.assertEqual(RelayHandler.requests[-2][1], "/v1/history/fills")
        self.assertEqual(RelayHandler.requests[-1][1], "/v1/history/transfers")

    def test_record_job_run(self):
        run = self.client.record_job_run(
            {"ok": True, "job": "pre_open_init", "trading_day": {"target_trade_date": "20260614"}},
            trigger="unit",
            status="completed",
            target_trade_date="20260614",
            timezone="Asia/Shanghai",
            duration_ms=1200,
        )
        self.assertEqual(run["run_id"], "job-1")
        method, path, _query, body = RelayHandler.requests[-1]
        self.assertEqual((method, path), ("POST", "/v1/jobs/runs"))
        self.assertEqual(body["trigger"], "unit")
        self.assertEqual(body["status"], "succeeded")
        self.assertEqual(body["target_trade_date"], "20260614")
        self.assertEqual(body["timezone"], "Asia/Shanghai")
        self.assertEqual(body["duration_ms"], 1200)

    def test_daily_job_review_helpers(self):
        runs = self.client.list_job_runs(
            job_names=["pre_open_init", "post_close_settlement"],
            trade_date="20260731",
            limit=20,
        )
        self.assertEqual(runs[0]["target_trade_date"], "20260731")
        method, path, query, _body = RelayHandler.requests[-1]
        self.assertEqual((method, path), ("GET", "/v1/jobs/runs"))
        self.assertEqual(query["job_name"], ["pre_open_init,post_close_settlement"])
        self.assertEqual(query["limit"], ["20"])
        review = self.client.get_daily_review_report(trade_date="20260731")
        self.assertEqual(review["status"], "passed")
        self.assertEqual(RelayHandler.requests[-1][1], "/v1/reconciliations/review-report")

    def test_performance_meridian_and_reconciliation_helpers(self):
        daily = self.client.get_performance_daily(trade_date="20260612")
        self.assertEqual(daily["net_asset"], 123.45)
        contributions = self.client.get_performance_contributions(trade_date="20260612")
        self.assertEqual(contributions["contributions"][0]["strategy_type"], "stock_cross_section")
        quality = self.client.get_trade_quality(date_from="20260612", date_to="20260613")
        self.assertEqual(quality["summary"]["executed_order_rate"], 0.8)
        self.assertEqual(RelayHandler.requests[-1][2]["date_from"], ["20260612"])
        with self.assertRaises(ValueError):
            self.client.get_trade_quality(trade_date="20260612", date_from="20260612")
        series = self.client.get_performance_series(date_from="20260612", date_to="20260612", benchmark_security_id="000300.SH")
        self.assertEqual(series["series"][0]["trade_date"], "20260612")
        csv_text = self.client.get_performance_series_csv(date_from="20260612", date_to="20260612", benchmark_security_id="000300.SH")
        self.assertIn("account_id,trade_date,net_asset", csv_text)
        self.assertEqual(RelayHandler.requests[-2][2]["benchmark_security_id"], ["000300.SH"])
        self.assertEqual(RelayHandler.requests[-1][2]["benchmark_security_id"], ["000300.SH"])
        preview = self.client.preview_economic_nav(trade_date="20260612")
        self.assertFalse(preview["persisted"])
        cost_preview = self.client.preview_cost_ledger(trade_date="20260612")
        self.assertFalse(cost_preview["persisted"])
        self.assertEqual(cost_preview["status"], "calculated")
        cost_rebuilt = self.client.rebuild_cost_ledger(trade_date="20260612")
        self.assertTrue(cost_rebuilt["persisted"])
        self.assertEqual(RelayHandler.requests[-1][2]["trade_date"], ["20260612"])
        rebuilt = self.client.rebuild_economic_nav(trade_date="20260612", status="finalized")
        self.assertTrue(rebuilt["persisted"])
        reconcile_preview = self.client.preview_economic_nav_reconciliation(trade_date="20260612", observed_trade_date="20260615")
        self.assertFalse(reconcile_preview["persisted"])
        self.assertEqual(reconcile_preview["observed_trade_date"], "20260615")
        reconcile_rebuild = self.client.rebuild_economic_nav_reconciliation(trade_date="20260612", observed_trade_date="20260615")
        self.assertTrue(reconcile_rebuild["persisted"])
        confirmed = self.client.confirm_nav_reconciliation(trade_date="20260612", operator="tester", note="ok", force=True)
        self.assertEqual(confirmed["status"], "confirmed")
        blocked = self.client.block_nav_reconciliation(trade_date="20260612", operator="risk", reconciliation_id="nav-recon-1")
        self.assertEqual(blocked["status"], "blocked")
        navs = self.client.list_economic_nav(trade_date="20260612")
        self.assertEqual(navs[0]["status"], "provisional")
        reconciliations = self.client.list_nav_reconciliations(trade_date="20260612")
        self.assertEqual(reconciliations[0]["status"], "auto_completed")
        breaks = self.client.list_reconciliation_breaks(run_id="run-1", status="open")
        self.assertEqual(breaks[0]["run_id"], "run-1")
        bars = self.client.get_meridian_bars(security_id="600000.SH", trade_date="20260612")
        self.assertEqual(bars["data"][0]["close"], 9.46)
        instruments = self.client.get_meridian_instruments(
            security_ids=["600000.SH", "510300.SH", "110075.SH"],
        )
        self.assertEqual(instruments["meta"]["schema_version"], "metadata_instrument.v2")
        ticks = {row["security_id"]: Decimal(str(row["price_tick"])) for row in instruments["data"]}
        self.assertEqual(ticks["600000.SH"], Decimal("0.01"))
        self.assertEqual(ticks["510300.SH"], Decimal("0.001"))
        self.assertEqual(ticks["110075.SH"], Decimal("0.001"))
        metadata_status = self.client.get_meridian_metadata_status()
        self.assertEqual(metadata_status["data"]["price_tick_quality"]["status"], "ready")
        factors = self.client.get_meridian_adjust_factors(security_id="600000.SH", start_date="20260601", end_date="20260612")
        self.assertEqual(factors["data"][0]["adj_factor"], 1.2345)
        components = self.client.get_meridian_etf_components(
            security_id="588200.SH",
            security_id_pattern="588*.SH",
            trade_date="20260729",
        )
        self.assertEqual(components["data"][0]["component_security_id"], "688361.SH")
        cash = self.client.get_meridian_etf_cash_components(security_ids=["588200.SH"], trade_date="20260729")
        self.assertEqual(cash["data"][0]["unit_subscribe_redeem"], "4500000")
        pcf_status = self.client.get_meridian_etf_pcf_status()
        self.assertEqual(pcf_status["data"]["state"]["status"], "success")

        requests = RelayHandler.requests[-7:]
        self.assertEqual(requests[0][1], "/v1/meridian/market/bars")
        self.assertEqual(requests[0][2]["trade_date"], ["20260612"])
        self.assertEqual(requests[1][1], "/v1/meridian/metadata/instruments")
        self.assertEqual(requests[1][2]["security_ids"], ["600000.SH,510300.SH,110075.SH"])
        self.assertEqual(requests[2][1], "/v1/meridian/metadata/status")
        self.assertEqual(requests[3][1], "/v1/meridian/metadata/adjust-factors")
        self.assertEqual(requests[3][2]["start_date"], ["20260601"])
        self.assertEqual(requests[4][1], "/v1/meridian/market/etf-components")
        self.assertEqual(requests[4][2]["security_id_pattern"], ["588*.SH"])
        self.assertEqual(requests[5][2]["security_ids"], ["588200.SH"])
        self.assertEqual(requests[6][1], "/v1/meridian/market/etf-pcf-status")

    def test_record_settlement_snapshot(self):
        result = self.client.record_settlement_snapshot(
            trade_date="20260612",
            account_ids=["acct-1"],
            run_id="settlement-20260612",
            input_snapshot_type="broker_close",
            captured_at="2026-06-12T15:01:04+08:00",
            snapshot_only=True,
            dry_run=True,
        )

        self.assertEqual(result["run_id"], "settlement-20260612")
        method, path, _query, body = RelayHandler.requests[-1]
        self.assertEqual((method, path), ("POST", "/v1/settlements/snapshots"))
        self.assertEqual(body["trade_date"], "20260612")
        self.assertEqual(body["account_ids"], ["acct-1"])
        self.assertEqual(body["input_snapshot_type"], "broker_close")
        self.assertEqual(body["captured_at"], "2026-06-12T15:01:04+08:00")
        self.assertTrue(body["snapshot_only"])
        self.assertTrue(body["dry_run"])

    def test_submit_order_generates_traceable_ids(self):
        receipt = self.client.submit_order(
            symbol="600000",
            exchange="SH",
            side="B",
            price=9.67,
            qty=100,
            trade_date="20260724",
            strategy_type="etf_t0",
            strategy_id="etf-arb",
            basket_id="basket-1",
            t0_order_group_id="t0-1",
        )
        self.assertTrue(receipt.gateway_order_id.startswith("sdk-gw-acct-1-"))
        self.assertEqual(receipt.action, "order.submit")
        self.assertEqual(receipt.client_order_id, receipt.gateway_order_id)
        self.assertEqual(receipt.request_id, "req-order-1")
        self.assertEqual(receipt.idempotency_key, f"order:acct-1:{receipt.gateway_order_id}")
        self.assertEqual(receipt.published["stream_id"], "1-0")
        self.assertEqual(receipt.status, "created")
        method, path, _query, body = RelayHandler.requests[-1]
        self.assertEqual((method, path), ("POST", "/v1/orders"))
        self.assertEqual(body["account_id"], "acct-1")
        self.assertEqual(body["idempotency_key"], f"order:acct-1:{body['gateway_order_id']}")
        self.assertEqual(body["trade_date"], "20260724")
        self.assertEqual(body["strategy_type"], "etf_t0")
        self.assertEqual(body["strategy_id"], "etf-arb")
        self.assertEqual(body["basket_id"], "basket-1")
        self.assertEqual(body["t0_order_group_id"], "t0-1")

    def test_command_receipt_decodes_write_action(self):
        receipt = CommandReceipt.from_dict(
            {
                "account_id": "acct-1",
                "action": "order.cancel",
                "message_id": "msg-1",
                "cancel_id": "cancel-1",
            }
        )
        self.assertEqual(receipt.action, "order.cancel")
        self.assertEqual(receipt.account_id, "acct-1")
        self.assertEqual(receipt.cancel_id, "cancel-1")

    def test_submit_order_replay_marker(self):
        receipt = self.client.submit_order(
            symbol="600000",
            exchange="SH",
            side="B",
            price=9.67,
            qty=100,
            gateway_order_id="gw-replay",
            client_order_id="client-replay",
            idempotency_key="idem-replay",
        )

        self.assertTrue(receipt.replayed)
        self.assertEqual(receipt.action, "order.submit")
        self.assertEqual(receipt.message_id, "msg-replay-1")
        self.assertEqual(receipt.stream_id, "1-0")
        self.assertEqual(receipt.status, "cancelled")

    def test_batch_receipt_preserves_explicit_ids_and_resolves_children(self):
        receipt = self.client.submit_orders(
            [
                {
                    "symbol": "600000",
                    "exchange": "SH",
                    "trade_side": "B",
                    "business_type": "S",
                    "price": 9.67,
                    "qty": 100,
                    "gateway_order_id": "gw-batch-1",
                    "client_order_id": "client-batch-1",
                    "idempotency_key": "idem-batch-1",
                },
                {
                    "symbol": "000001",
                    "exchange": "SZ",
                    "trade_side": "B",
                    "business_type": "S",
                    "price": 11.24,
                    "qty": 100,
                    "gateway_order_id": "gw-batch-2",
                    "client_order_id": "client-batch-2",
                    "idempotency_key": "idem-batch-2",
                },
            ],
            idempotency_key="batch-explicit-1",
        )

        self.assertIsInstance(receipt, BatchCommandReceipt)
        self.assertEqual(receipt.action, "order.batch.submit")
        self.assertEqual(receipt.account_id, "acct-1")
        self.assertEqual(receipt.message_id, "msg-batch-1")
        self.assertEqual(receipt.request_id, "req-batch-1")
        self.assertEqual(receipt.idempotency_key, "batch-explicit-1")
        self.assertEqual([child.acceptance for child in receipt.children], ["accepted", "accepted"])
        self.assertEqual([child.outcome for child in receipt.children], ["pending", "pending"])
        method, path, _query, body = RelayHandler.requests[-1]
        self.assertEqual((method, path), ("POST", "/v1/orders/batch"))
        self.assertEqual(body["orders"][0]["gateway_order_id"], "gw-batch-1")
        self.assertEqual(body["orders"][0]["client_order_id"], "client-batch-1")
        self.assertEqual(body["orders"][0]["idempotency_key"], "idem-batch-1")

        outcomes = self.client.wait_batch_order_outcomes(receipt, timeout=1, poll_interval=0.01)
        self.assertTrue(outcomes.complete)
        self.assertEqual([child.gateway_order_id for child in outcomes.children], ["gw-batch-1", "gw-batch-2"])
        self.assertEqual([child.outcome for child in outcomes.children], ["accepted", "rejected"])
        self.assertEqual(outcomes.children[1].code, "ORDER_SUBMIT_REJECTED")

    def test_batch_outcome_unknown_is_explicit(self):
        outcomes = self.client.get_batch_order_outcomes("msg-batch-unknown")
        self.assertTrue(outcomes.complete)
        self.assertEqual(len(outcomes.children), 1)
        self.assertEqual(outcomes.children[0].outcome, "outcome_unknown")
        self.assertEqual(outcomes.children[0].code, "COMMAND_OUTCOME_UNKNOWN")

    def test_replayed_batch_has_per_child_replay_acceptance(self):
        receipt = self.client.submit_orders(
            [
                {
                    "symbol": "600000",
                    "exchange": "SH",
                    "trade_side": "B",
                    "business_type": "S",
                    "price": 9.67,
                    "qty": 100,
                    "gateway_order_id": "gw-replayed-batch",
                    "client_order_id": "client-replayed-batch",
                    "idempotency_key": "idem-replayed-batch",
                }
            ],
            idempotency_key="batch-replay",
        )
        self.assertTrue(receipt.replayed)
        self.assertEqual(receipt.action, "order.batch.submit")
        self.assertEqual(receipt.message_id, "msg-batch-replay")
        self.assertEqual(receipt.children[0].acceptance, "replayed")
        self.assertEqual(receipt.children[0].outcome, "accepted")
        outcomes = self.client.get_batch_order_outcomes(receipt)
        self.assertTrue(outcomes.complete)
        self.assertEqual(outcomes.children[0].acceptance, "replayed")

    def test_refresh_and_cancel(self):
        self.assertEqual(self.client.refresh_orders().action, "order.list.query")
        self.assertEqual(self.client.refresh_fills().action, "fill.list.query")
        self.assertEqual(self.client.refresh_fees().action, "fee.list.query")
        cancel = self.client.cancel_order("gw-1")
        self.assertEqual(cancel.gateway_order_id, "gw-1")
        self.assertEqual(cancel.action, "order.cancel")

    def test_write_receipt_missing_or_wrong_action_is_outcome_unknown(self):
        for idempotency_key in ("missing-action", "wrong-action"):
            with self.subTest(idempotency_key=idempotency_key):
                with self.assertRaises(RelayCommandOutcomeUnknownError) as raised:
                    self.client.submit_order(
                        symbol="600000",
                        exchange="SH",
                        side="B",
                        price=9.67,
                        qty=100,
                        idempotency_key=idempotency_key,
                    )
                self.assertEqual(raised.exception.code, "WRITE_RECEIPT_ACTION_MISMATCH")
                self.assertTrue(raised.exception.retry_decision("write").requires_reconciliation)

    def test_list_order_fees(self):
        fees = self.client.list_order_fees(
            trade_date="20260801",
            gateway_order_id="gw-fee-1",
            fee_complete=True,
        )
        self.assertEqual(len(fees), 1)
        self.assertEqual(fees[0].gateway_order_id, "gw-fee-1")
        self.assertEqual(fees[0].total_fee, 6.25)
        self.assertTrue(fees[0].fee_complete)
        method, path, query, _body = RelayHandler.requests[-1]
        self.assertEqual((method, path), ("GET", "/v1/accounts/acct-1/fees"))
        self.assertEqual(query["fee_complete"], ["true"])

    def test_wait_order_terminal(self):
        order = self.client.wait_order_terminal("gw-1", timeout=1, poll_interval=0.01)
        self.assertTrue(order.is_terminal)
        self.assertEqual(order.filled_qty, 100)

    def test_error_mapping(self):
        with self.assertRaises(RelayIdempotencyError):
            self.client._request("POST", "/v1/error", json_body={})
        with self.assertRaises(RelayBrokerNotReadyError):
            self.client._request("POST", "/v1/broker-not-ready", json_body={})

        self.assertIsInstance(
            error_from_payload({"error": {"code": "BROKER_CANCEL_REJECTED", "message": "cancel rejected"}}),
            RelayCancelRejectedError,
        )
        self.assertIsInstance(
            error_from_payload({"error": {"code": "COMMAND_OUTCOME_UNKNOWN", "message": "reconcile first"}}),
            RelayCommandOutcomeUnknownError,
        )
        self.assertIsInstance(
            error_from_payload({"error": {"code": "QUERY_INTERRUPTED", "message": "retry query"}}),
            RelayQueryInterruptedError,
        )

    def test_sse_parser(self):
        stream = BytesIO(
            b'id: evt-test-1\n'
            b'event: order.changed\n'
            b'data: {"account_ids":["acct-1"],"time":"2026-06-14T00:00:00Z","data":{"orders":1}}\n'
            b"\n"
        )
        event = next(iter_sse_events(stream))
        self.assertEqual(event.event_id, "evt-test-1")
        self.assertEqual(event.id, "evt-test-1")
        self.assertEqual(event.event_type, "order.changed")
        self.assertEqual(event.account_ids, ("acct-1",))
        self.assertEqual(event.data["orders"], 1)

    def test_stream_events_sends_last_event_id(self):
        stream = self.client.stream_events(last_event_id="evt-test-42", idle_timeout=2)
        event = next(stream)
        stream.close()
        self.assertEqual(event.event_type, "order.changed")
        self.assertEqual(RelayHandler.last_event_id, "evt-test-42")

    def test_reconcile_current_state_reads_complete_ledger(self):
        snapshot = self.client.reconcile_current_state(reason="server_restart", last_event_id="evt-old-9")
        self.assertEqual(snapshot.account_id, "acct-1")
        self.assertEqual(snapshot.reason, "server_restart")
        self.assertEqual(snapshot.last_event_id, "evt-old-9")
        self.assertEqual(snapshot.asset.account_id, "acct-1")
        self.assertEqual(len(snapshot.positions), 1)
        self.assertEqual(len(snapshot.orders), 1)
        self.assertEqual(len(snapshot.fills), 1)

    def test_order_status_callback_fetches_orders_after_event(self):
        seen = []

        def callback(order, event):
            seen.append((order, event.event_type))
            return False

        subscription = self.client.on_order_status(
            callback,
            gateway_order_id="gw-1",
        )
        subscription.join(timeout=2)

        self.assertFalse(subscription.is_alive)
        self.assertIsNone(subscription.error)
        self.assertEqual(len(seen), 1)
        self.assertEqual(seen[0][0].status, "filled")
        self.assertEqual(seen[0][1], "order.changed")
        self.assertIn(("GET", "/v1/events/stream", {"account_id": ["acct-1"]}, None), RelayHandler.requests)

    def test_fill_callback_fetches_fills_after_event(self):
        seen = []

        def callback(fill, event):
            seen.append((fill, event.event_type))
            return False

        self.client.watch_fills(callback)

        self.assertEqual(len(seen), 1)
        self.assertEqual(seen[0][0].fill_id, "fill-1")
        self.assertEqual(seen[0][1], "fill.changed")

    def test_fill_callback_allows_same_fill_id_on_different_orders(self):
        seen = []

        def callback(fill, _event):
            seen.append((fill.gateway_order_id, fill.fill_id, fill.qty))
            return len(seen) < 2

        self.client.watch_fills(
            callback,
            symbol="dup-fill",
        )

        self.assertEqual(seen, [("gw-a", "reused-fill", 100), ("gw-b", "reused-fill", 200)])

    def test_cancel_rejected_callback_receives_attempt_context(self):
        seen = []

        def callback(event):
            seen.append(event.data["cancel_attempt"])
            return False

        self.client.watch_cancel_rejections(
            callback,
            gateway_order_id="gw-cancel-rejected",
        )

        self.assertEqual(len(seen), 1)
        self.assertEqual(seen[0]["code"], "BROKER_CANCEL_REJECTED")

    def test_callback_keys_include_trade_date(self):
        self.assertNotEqual(
            _order_key(Order(account_id="acct-1", trade_date="2026-07-28", gateway_order_id="gw-1")),
            _order_key(Order(account_id="acct-1", trade_date="2026-07-29", gateway_order_id="gw-1")),
        )
        self.assertNotEqual(
            _fill_key(Fill(account_id="acct-1", trade_date="2026-07-28", gateway_order_id="gw-1", fill_id="fill-1")),
            _fill_key(Fill(account_id="acct-1", trade_date="2026-07-29", gateway_order_id="gw-1", fill_id="fill-1")),
        )


if __name__ == "__main__":
    unittest.main()
